const help = (prefix) => {
	return `
╔══✪〘 INFO 〙✪══
║
╠➥ FRIBOI 𝐁𝐎𝐓
╠➥ 𝐃𝐎𝐍𝐎:  ғᷫʀᷢɪͥʙᷨᴏͦɪͥ ⃘⃤🐊
╠➥ *wa.me/+5515998576105*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 MAIS USADOS 〙✪══
║
║ *${prefix}tts pt [texto]*
║ *${prefix}sticker*
║ *${prefix}toimg*
║ *${prefix}darkjokes (memes aleatórios)*
║ *${prefix}memeindo*
║ *${prefix}leens [na legenda]*
║ *${prefix}wait [na legenda]*
║ *${prefix}pinterest (nome)*
║
╠══✪〘 IMAGENS 〙✪══
║
║ *${prefix}boanoite*
║ *${prefix}bomdia*
║ *${prefix}boatarde*
║ *${prefix}neko*
║ *${prefix}rize [aleatórias]*
║ *${prefix}minato [aleatórias]*
║ *${prefix}boruto [aleatórias]*
║ *${prefix}hinata [aleatórias]*
║ *${prefix}sasuke [aleatórias]*
║ *${prefix}sakura [aleatórias]*
║ *${prefix}naruto [aleatórias]*
║ *${prefix}meme*   
║ *${prefix}darkjokes (memes aleatórios)*
║
╠══✪〘 DONO 〙✪══
║
║ *${prefix}bloquear [@]*
║ *${prefix}desbloquear [@]*
║ *${prefix}limpar*
║ *${prefix}setnome*
║ *${prefix}setfoto*
║ *${prefix}bc [texto]* (ele faz uma ™)
║
╠══✪〘 INTELIGÊNCIA IA 〙✪══
║
║ *${prefix}simih 1 (para ativar)*
║ *${prefix}simih 0 (para desativar)*
║ *${prefix}simi
║
╠══✪〘 PREMIUM 〙✪══
║
║ *${prefix}dado*(ROLAR DADO)
║ *${prefix}cekvip*
║ *${prefix}premiumlist*
║ *${prefix}delete*
║ *${prefix}modapk*
║ *${prefix}qrcode*
║ *${prefix}gcpf*
║ *${prefix}gbin*
║ *${prefix}pack*
║ *${prefix}gpessoa*
║
╠══✪〘 ADMINS 〙✪══
║
║ *${prefix}banir*
║ *${prefix}leveling [on/off]*
║ *${prefix}add @*
║ *${prefix}promover @*
║ *${prefix}rebaixar*
║ *${prefix}setfoto [na legenda]*
║ *${prefix}setdesc*
║ *${prefix}marcar*
║ *${prefix}marcar2*
║ *${prefix}marcar3*
║ *${prefix}bemvindo [1/0]*
║
╠══✪〘 GRUPO 〙✪══
║
║ *${prefix}level*
║ *${prefix}admins*
║ *${prefix}grupoinfo*
║ *${prefix}bug [sua mensagem]*
║ *${prefix}gay [@]*
║ *${prefix}wame*
║ *${prefix}map (nome)*
║
╠══✪〘 OUTROS 〙✪══
║
║ *${prefix}happymod [jogo/app]*
║ *${prefix}ytsearch*
║ *${prefix}moddroid [jogo/app]*
║ *${prefix}xvideos [titulo]**
║ *${prefix}animecry*
║ *${prefix}next*
║ *${prefix}alerta*
║ *${prefix}hobby*
║ *${prefix}animecry*
║ *${prefix}wame*
║ *${prefix}play (nome da msc)*
║ *${prefix}ping [ver velocidade do bot]*
║ *${prefix}bloqueados*
║ *${prefix}help1*
║
╠══✪〘 COMANDOS DE VOZ 〙✪══
║
║ *${prefix}ola*
║ *${prefix}bv*
║ *${prefix}tchau*
║ *${prefix}bem*
║ *${prefix}a*
║ *${prefix}fdp*
║ *${prefix}onich*
║ *${prefix}beat1*
║ *${prefix}glub*
║
╠══✪〘 INTERATIVOS 〙✪══
║NOTA »
║Mandar a msg sem o prefixo
║
║ *bah*
║ *oii*
║ *bv*
║ *canta ai bot*
║ *grita*
║
╚═〘 FRIBOI 𝐁𝐎𝐓 〙`
}

exports.help = help

